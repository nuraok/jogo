export function falas(cenas) {
    switch (cenas) {
        case 1:
            break;
        case 2:


            break
    }
}
